/**
 * THE HEROES：勇者之境 v0.2
 * Google Apps Script backend
 */

const CONFIG = {
  SHEET_NAME: 'Players',
  REQUIRED_HEADERS: [
    'userId','displayName','pictureUrl','level','exp','gold','gems',
    'hp','maxHp','attack','defense','stage','monsterIndex',
    'totalKills','lastSeen','createdAt'
  ]
};

function doGet() {
  const t = HtmlService.createTemplateFromFile('Index');
  const props = PropertiesService.getScriptProperties();
  t.liffId = props.getProperty('LIFF_ID') || '';
  return t.evaluate()
    .setTitle('THE HEROES：勇者之境')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, viewport-fit=cover');
}

function setupGame() {
  const cfg = validateConfig_();
  const ss = SpreadsheetApp.openById(cfg.SPREADSHEET_ID);
  let sh = ss.getSheetByName(CONFIG.SHEET_NAME);
  if (!sh) sh = ss.insertSheet(CONFIG.SHEET_NAME);

  const headers = sh.getLastColumn() > 0
    ? sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0]
    : [];

  if (sh.getLastRow() === 0 || headers.length === 0) {
    sh.getRange(1, 1, 1, CONFIG.REQUIRED_HEADERS.length)
      .setValues([CONFIG.REQUIRED_HEADERS]);
  } else {
    const missing = CONFIG.REQUIRED_HEADERS.filter(h => !headers.includes(h));
    if (missing.length) {
      sh.getRange(1, headers.length + 1, 1, missing.length).setValues([missing]);
    }
  }

  sh.setFrozenRows(1);
  sh.autoResizeColumns(1, sh.getLastColumn());

  return {
    ok: true,
    message: 'THE HEROES 初始化完成',
    spreadsheetName: ss.getName(),
    sheetName: sh.getName()
  };
}

function healthCheck() {
  try {
    const cfg = validateConfig_();
    const ss = SpreadsheetApp.openById(cfg.SPREADSHEET_ID);
    const sh = ss.getSheetByName(CONFIG.SHEET_NAME);

    return {
      ok: true,
      liffId: cfg.LIFF_ID,
      lineChannelId: cfg.LINE_CHANNEL_ID,
      spreadsheetName: ss.getName(),
      playersSheetExists: !!sh
    };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e) };
  }
}

function loginWithLine(idToken) {
  if (!idToken) throw new Error('E101：沒有收到 LINE ID token。請確認 LIFF Scope 已勾選 openid。');

  const profile = verifyLineIdToken_(idToken);
  let player = getPlayer_(profile.sub);

  if (!player) {
    player = createPlayer_(profile.sub, profile.name || '勇者', profile.picture || '');
  } else {
    touchPlayer_(profile.sub, profile.name || player.displayName, profile.picture || player.pictureUrl);
    player = getPlayer_(profile.sub);
  }

  return { ok: true, player: sanitizeForClient_(player) };
}

function saveProgress(idToken, patch) {
  if (!idToken) throw new Error('E201：缺少登入憑證。');

  const profile = verifyLineIdToken_(idToken);
  const sh = getPlayersSheet_();
  const row = findPlayerRow_(sh, profile.sub);
  if (!row) throw new Error('E202：找不到玩家資料，請重新進入遊戲。');

  const header = getHeader_(sh);
  const values = sh.getRange(row, 1, 1, header.length).getValues()[0];
  const obj = rowToObject_(header, values);

  const allowed = [
    'level','exp','gold','gems','hp','maxHp','attack','defense',
    'stage','monsterIndex','totalKills'
  ];

  Object.keys(patch || {}).forEach(k => {
    if (!allowed.includes(k)) return;
    const n = Number(patch[k]);
    if (!Number.isFinite(n)) return;
    obj[k] = Math.max(0, Math.floor(n));
  });

  obj.lastSeen = new Date();
  sh.getRange(row, 1, 1, header.length).setValues([header.map(h => obj[h] ?? '')]);

  return { ok: true, player: sanitizeForClient_(obj) };
}

function verifyLineIdToken_(idToken) {
  const cfg = validateConfig_();

  const response = UrlFetchApp.fetch('https://api.line.me/oauth2/v2.1/verify', {
    method: 'post',
    contentType: 'application/x-www-form-urlencoded',
    payload: {
      id_token: idToken,
      client_id: cfg.LINE_CHANNEL_ID
    },
    muteHttpExceptions: true
  });

  const status = response.getResponseCode();
  const text = response.getContentText();

  if (status !== 200) {
    throw new Error('E102：LINE ID token 驗證失敗。HTTP ' + status + ' / ' + text);
  }

  const data = JSON.parse(text);
  if (!data.sub) throw new Error('E103：LINE 回傳資料沒有 user ID。');

  if (String(data.aud || '') !== String(cfg.LINE_CHANNEL_ID)) {
    throw new Error('E104：LINE Channel ID 與 LIFF 所屬 Channel 不一致。');
  }

  return data;
}

function createPlayer_(userId, displayName, pictureUrl) {
  const sh = getPlayersSheet_();
  const now = new Date();
  const row = {
    userId, displayName, pictureUrl,
    level: 1, exp: 0, gold: 100, gems: 10,
    hp: 120, maxHp: 120, attack: 18, defense: 5,
    stage: 1, monsterIndex: 0, totalKills: 0,
    lastSeen: now, createdAt: now
  };
  sh.appendRow(CONFIG.REQUIRED_HEADERS.map(h => row[h] ?? ''));
  return row;
}

function getPlayer_(userId) {
  const sh = getPlayersSheet_();
  const row = findPlayerRow_(sh, userId);
  if (!row) return null;

  const header = getHeader_(sh);
  const values = sh.getRange(row, 1, 1, header.length).getValues()[0];
  return rowToObject_(header, values);
}

function touchPlayer_(userId, displayName, pictureUrl) {
  const sh = getPlayersSheet_();
  const row = findPlayerRow_(sh, userId);
  if (!row) return;

  const header = getHeader_(sh);
  const map = Object.fromEntries(header.map((h, i) => [h, i + 1]));
  if (map.displayName) sh.getRange(row, map.displayName).setValue(displayName);
  if (map.pictureUrl) sh.getRange(row, map.pictureUrl).setValue(pictureUrl);
  if (map.lastSeen) sh.getRange(row, map.lastSeen).setValue(new Date());
}

function getPlayersSheet_() {
  const cfg = validateConfig_();
  const ss = SpreadsheetApp.openById(cfg.SPREADSHEET_ID);
  const sh = ss.getSheetByName(CONFIG.SHEET_NAME);
  if (!sh) throw new Error('E301：找不到 Players 工作表。請先執行 setupGame()。');
  return sh;
}

function findPlayerRow_(sh, userId) {
  if (sh.getLastRow() < 2) return null;
  const finder = sh.getRange(2, 1, sh.getLastRow() - 1, 1)
    .createTextFinder(String(userId))
    .matchEntireCell(true)
    .findNext();
  return finder ? finder.getRow() : null;
}

function getHeader_(sh) {
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
}

function rowToObject_(header, values) {
  const obj = {};
  header.forEach((h, i) => obj[h] = values[i]);
  return obj;
}

function sanitizeForClient_(obj) {
  const out = { ...obj };
  ['lastSeen','createdAt'].forEach(k => {
    if (out[k] instanceof Date) out[k] = out[k].toISOString();
  });
  return out;
}

function validateConfig_() {
  const props = PropertiesService.getScriptProperties();
  const cfg = {
    SPREADSHEET_ID: (props.getProperty('SPREADSHEET_ID') || '').trim(),
    LIFF_ID: (props.getProperty('LIFF_ID') || '').trim(),
    LINE_CHANNEL_ID: (props.getProperty('LINE_CHANNEL_ID') || '').trim()
  };

  if (!cfg.SPREADSHEET_ID) throw new Error('C001：尚未設定 SPREADSHEET_ID');
  if (!cfg.LIFF_ID) throw new Error('C002：尚未設定 LIFF_ID');
  if (!cfg.LINE_CHANNEL_ID) throw new Error('C003：尚未設定 LINE_CHANNEL_ID');

  const prefix = cfg.LIFF_ID.split('-')[0];
  if (prefix && prefix !== cfg.LINE_CHANNEL_ID) {
    throw new Error('C004：LIFF_ID 前段 (' + prefix + ') 與 LINE_CHANNEL_ID (' + cfg.LINE_CHANNEL_ID + ') 不一致');
  }

  return cfg;
}
