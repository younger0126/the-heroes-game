THE HEROES：勇者之境 v0.2 修正版

請用「全新的 Google Apps Script 專案」，不要跟之前的網站專案混在一起。

1. 新增一個空白 Google Sheet，複製 Spreadsheet ID。

2. 建立全新 Apps Script 專案：
   THE HEROES 勇者之境

3. 放入：
   Code.gs
   Index.html
   appsscript.json

4. Apps Script → 專案設定 → 指令碼屬性，設定：
   LIFF_ID = 2011020275-gl2HOIoL
   LINE_CHANNEL_ID = 2011020275
   SPREADSHEET_ID = 你的遊戲 Google Sheet ID

5. 在 Apps Script 上方選 setupGame → 執行。
   第一次會要求授權。
   成功後 Google Sheet 必須出現 Players 工作表。

6. 可再執行 healthCheck。
   如果成功會回傳 ok: true。

7. 部署 → 新增部署作業 → 網頁應用程式
   執行身分：我
   誰可以存取：任何人

8. 複製新的 /exec 網址。

9. LINE Developers → LINE Login Channel → LIFF → Edit
   Endpoint URL 改成新的 GAS /exec 網址。
   Scope 確認勾選：
   profile
   openid
   Size：Full

10. 從：
    https://liff.line.me/2011020275-gl2HOIoL
    在 LINE 裡開啟測試。

v0.2 改善：
- 若 LIFF_ID、Channel ID、Players 工作表或 LINE Token 有問題，會直接在遊戲畫面顯示錯誤代碼。
- setupGame 自動建立 Players。
- healthCheck 可快速檢查設定。
- LINE ID token 會在 GAS 後端向 LINE 驗證。
